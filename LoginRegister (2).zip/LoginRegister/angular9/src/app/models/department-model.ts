export class Department {
    DepartmentID: number;
    DepartmentName: string;
}