export class Employee {
    EmployeeID: number;
    EmployeeName: string;
    Department: string;
    MailID: string;
    DOJ: Date;
    Salary: number;
    Age: number;
    Address: string;
    Phone: number;
}