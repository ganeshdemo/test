/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-bootstrap/buttons" />
export * from './index';
