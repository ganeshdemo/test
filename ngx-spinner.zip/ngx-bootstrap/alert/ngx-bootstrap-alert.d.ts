/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-bootstrap/alert" />
export * from './index';
