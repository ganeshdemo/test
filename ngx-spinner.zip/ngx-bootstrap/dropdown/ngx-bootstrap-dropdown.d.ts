/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-bootstrap/dropdown" />
export * from './index';
