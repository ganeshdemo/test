import { AnimationMetadata } from '@angular/animations';
export declare const DROPDOWN_ANIMATION_TIMING = "220ms cubic-bezier(0, 0, 0.2, 1)";
export declare const dropdownAnimation: AnimationMetadata[];
