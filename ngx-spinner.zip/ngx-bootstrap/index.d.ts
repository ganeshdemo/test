declare const _default: {};
export default _default;
