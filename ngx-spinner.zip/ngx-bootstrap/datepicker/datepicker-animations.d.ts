import { AnimationTriggerMetadata } from '@angular/animations';
export declare const DATEPICKER_ANIMATION_TIMING = "220ms cubic-bezier(0, 0, 0.2, 1)";
export declare const datepickerAnimation: AnimationTriggerMetadata;
