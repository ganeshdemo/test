import { BsDatepickerState } from './bs-datepicker.state';
import { Action } from 'ngx-bootstrap/mini-ngrx';
export declare function bsDatepickerReducer(state: BsDatepickerState | undefined, action: Action): BsDatepickerState;
