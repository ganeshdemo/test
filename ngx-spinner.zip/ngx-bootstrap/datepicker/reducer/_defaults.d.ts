import { MonthViewOptions } from '../models';
export declare const defaultMonthOptions: MonthViewOptions;
export declare const dayInMilliseconds: number;
