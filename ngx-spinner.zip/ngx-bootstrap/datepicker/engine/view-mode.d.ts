import { BsDatepickerViewMode } from '../models';
export declare function canSwitchMode(mode: BsDatepickerViewMode, minMode?: BsDatepickerViewMode): boolean;
