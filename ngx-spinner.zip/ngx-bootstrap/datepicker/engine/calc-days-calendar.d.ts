import { DaysCalendarModel, MonthViewOptions } from '../models';
export declare function calcDaysCalendar(startingDate: Date, options: MonthViewOptions): DaysCalendarModel;
