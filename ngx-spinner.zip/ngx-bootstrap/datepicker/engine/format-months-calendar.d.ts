import { DatepickerFormatOptions, MonthsCalendarViewModel } from '../models';
export declare function formatMonthsCalendar(viewDate: Date, formatOptions: DatepickerFormatOptions): MonthsCalendarViewModel;
