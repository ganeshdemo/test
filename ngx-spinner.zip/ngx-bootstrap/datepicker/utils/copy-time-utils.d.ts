export declare function copyTime(sourceDate: Date, time: Date): void;
