import { BsDatepickerConfig } from './bs-datepicker.config';
import * as i0 from "@angular/core";
export declare class BsDatepickerInlineConfig extends BsDatepickerConfig {
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDatepickerInlineConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsDatepickerInlineConfig>;
}
