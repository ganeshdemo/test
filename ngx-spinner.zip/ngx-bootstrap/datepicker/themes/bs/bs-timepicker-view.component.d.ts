import * as i0 from "@angular/core";
export declare class BsTimepickerViewComponent {
    ampm: string;
    hours: number;
    minutes: number;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsTimepickerViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BsTimepickerViewComponent, "bs-timepicker", never, {}, {}, never, never>;
}
