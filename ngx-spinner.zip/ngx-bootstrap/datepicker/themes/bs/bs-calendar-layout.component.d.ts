import * as i0 from "@angular/core";
export declare class BsCalendarLayoutComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BsCalendarLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BsCalendarLayoutComponent, "bs-calendar-layout", never, {}, {}, never, ["bs-datepicker-navigation-view", "*"]>;
}
