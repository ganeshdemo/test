import * as i0 from "@angular/core";
export declare class BsCurrentDateViewComponent {
    title?: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsCurrentDateViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BsCurrentDateViewComponent, "bs-current-date", never, { "title": "title"; }, {}, never, never>;
}
