import { BsDatepickerConfig } from './bs-datepicker.config';
import * as i0 from "@angular/core";
export declare class BsDaterangepickerConfig extends BsDatepickerConfig {
    displayMonths: number;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDaterangepickerConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsDaterangepickerConfig>;
}
