export { FocusTrapModule } from './focus-trap.module';
export { FocusTrap } from './focus-trap';
export { FocusTrapDirective } from './focus-trap';
