/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-bootstrap/accordion" />
export * from './index';
