import { DateObject } from '../types';
export declare function isDurationValid(duration: Partial<DateObject>): boolean;
