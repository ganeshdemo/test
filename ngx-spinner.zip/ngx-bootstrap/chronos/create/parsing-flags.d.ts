import { DateParsingConfig, DateParsingFlags } from './parsing.types';
export declare function getParsingFlags(config: DateParsingConfig): DateParsingFlags;
