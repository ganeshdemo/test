import { DateInput } from '../testing/chain';
export declare function parseDate(input: DateInput, format?: string | string[], localeKey?: string, strict?: boolean, isUTC?: boolean): Date;
export declare function utcAsLocal(date: any): Date;
