import { DateParsingConfig } from './parsing.types';
export declare function checkOverflow(config: DateParsingConfig): DateParsingConfig;
