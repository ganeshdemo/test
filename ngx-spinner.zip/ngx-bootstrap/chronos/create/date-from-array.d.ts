export declare function createUTCDate(y?: number, m?: number, d?: number): Date;
export declare function createDate(y?: number, m?: number, d?: number, h?: number, M?: number, s?: number, ms?: number): Date;
