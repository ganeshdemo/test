export declare function initMillisecond(): void;
