export declare function daysInMonth(year: number, month: number): number;
export declare function initMonth(): void;
