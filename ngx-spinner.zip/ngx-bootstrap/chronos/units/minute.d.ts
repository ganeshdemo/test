export declare function initMinute(): void;
