import { LocaleData } from '../locale/locale.class';
export declare const itLocale: LocaleData;
