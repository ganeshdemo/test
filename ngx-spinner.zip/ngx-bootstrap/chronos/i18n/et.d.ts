import { LocaleData } from '../locale/locale.class';
export declare const etLocale: LocaleData;
