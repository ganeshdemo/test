import { LocaleData } from '..';
export declare const kkLocale: LocaleData;
