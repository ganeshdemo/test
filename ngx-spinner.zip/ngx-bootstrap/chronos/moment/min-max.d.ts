export declare function min(...args: Date[]): Date;
export declare function max(...args: Date[]): Date;
