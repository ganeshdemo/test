export declare function absRound(num: number): number;
