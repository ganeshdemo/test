export { arLocale, bgLocale, caLocale, csLocale, daLocale, deLocale, enGbLocale, esDoLocale, esLocale, esPrLocale, esUsLocale, etLocale, fiLocale, frLocale, glLocale, heLocale, hiLocale, hrLocale, huLocale, idLocale, itLocale, jaLocale, kaLocale, kkLocale, koLocale, ltLocale, lvLocale, mnLocale, nbLocale, nlBeLocale, nlLocale, plLocale, ptBrLocale, roLocale, ruLocale, skLocale, slLocale, sqLocale, svLocale, thBeLocale, thLocale, trLocale, ukLocale, viLocale, zhCnLocale } from 'ngx-bootstrap/chronos';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ngx-bootstrap-locale.mjs.map
